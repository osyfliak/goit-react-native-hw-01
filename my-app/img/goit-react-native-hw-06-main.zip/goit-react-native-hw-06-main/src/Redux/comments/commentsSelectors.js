export const selectComments = store => store.comments.comments;

export const selectAllStore = store => store;