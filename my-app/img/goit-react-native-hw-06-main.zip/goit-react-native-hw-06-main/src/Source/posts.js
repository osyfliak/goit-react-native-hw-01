const data = [{
    id:"1",
    name:"Forest",
    location:"Ivano-Frankivs'k Region, Ukraine"
},
{
    id:"2",
    name:"Black Sea Sunset",
    location:"Ukraine"
},
{
    id:"3",
    name:"Venecia old house",
    location:"Italy"
}];

export default data;